﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Antra.CompanyApp.Data.Model
{
    public class Region
    {
        public int RegionId { get; set; }
        public string RegionDescription { get; set; }
    }
}
