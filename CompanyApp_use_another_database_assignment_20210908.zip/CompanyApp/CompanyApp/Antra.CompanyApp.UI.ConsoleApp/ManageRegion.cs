﻿using System;
using System.Collections.Generic;
using System.Text;
using Antra.CompanyApp.Data.Repository;
using Antra.CompanyApp.Data.Model;
namespace Antra.CompanyApp.UI.ConsoleApp
{
    class ManageRegion
    {
        IRepository<Region> regionRepository;
        public ManageRegion()
        {
            regionRepository = new RegionRepository();
        }

        void AddRegion()
        {
            Region d = new Region();
            Console.Write("Enter RegionId => ");
            d.RegionId = Console.ReadLine();
            Console.Write("Enter RegionDescription => ");
            d.RegionDescription = Console.ReadLine();

            if (regionRepository.Insert(d) > 0)
                Console.WriteLine("Region Added Successfully");
            else
                Console.WriteLine("Some error has occured");
        }
        void DeleteRegion()
        {
            Console.Write("Enter RegionId => ");
            int id = Convert.ToInt32(Console.ReadLine());
            if (regionRepository.Delete(id) > 0)
                Console.WriteLine("Region Deleted Successfully");
            else
                Console.WriteLine("Some error has occured");
        }

        void UpdateRegion()
        {
            Region d = new Region();
            Console.Write("Enter RegionId => ");
            d.RegionId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter RegionDescription => ");
            d.RegionDescription = Console.ReadLine();
            

            if (regionRepository.Update(d) > 0)
                Console.WriteLine("Region Updated Successfully");
            else
                Console.WriteLine("Some error has occured");
        }

        void PrintAll()
        {
            IEnumerable<Region> regionCollection = regionRepository.GetAll();
            if (regionCollection != null)
            { 
               foreach(var item in regionCollection)
                    Console.WriteLine(item.RegionId+"\t"+item.RegionDescription);
            }
        }

        public void Run()
        {
            PrintAll();
        }
    }
}
