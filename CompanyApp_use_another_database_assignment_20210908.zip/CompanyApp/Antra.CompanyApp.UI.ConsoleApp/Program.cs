﻿using System;

namespace Antra.CompanyApp.UI.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {

            ManageRegion manageRegion = new ManageRegion();
            manageRegion.Run();
        }
    }
}
