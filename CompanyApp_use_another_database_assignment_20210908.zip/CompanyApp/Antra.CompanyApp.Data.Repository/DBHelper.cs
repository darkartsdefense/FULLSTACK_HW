﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using Microsoft.Extensions.Configuration.Json;
using Microsoft.Extensions.Configuration;
namespace Antra.CompanyApp.Data.Repository
{
    class DBHelper
    {
        public string ConnectionString
        {
            get
            {
                return new ConfigurationBuilder().AddJsonFile("appSettings.json").Build().GetConnectionString("Northwind");

            }
        }
        public int Execute(string sqlCommand, Dictionary<string, object> parameters, CommandType cmdType = CommandType.Text)
        {
            SqlConnection connection = new SqlConnection(ConnectionString);

            SqlCommand command = new SqlCommand();
            try
            {
                command.CommandType = cmdType;
                connection.Open();
                command.CommandText = sqlCommand;
                if (parameters != null)
                {
                    foreach (var item in parameters)
                    {
                        command.Parameters.AddWithValue(item.Key, item.Value);
                    }
                }

                command.Connection = connection;

                return command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // log the exception to files
            }
            finally
            {
                connection.Close();
                connection.Dispose();
                command.Dispose();
            }

            return 0;
        }

        public DataTable Query(string sqlCommand, Dictionary<string, object> parameters, CommandType cmdType = CommandType.Text)
        {
            SqlConnection connection = new SqlConnection(ConnectionString);

            SqlCommand command = new SqlCommand();

            try
            {
                command.CommandType = cmdType;
                command.CommandText = sqlCommand;
                if (parameters != null)
                {
                    foreach (var item in parameters)
                    {
                        command.Parameters.AddWithValue(item.Key, item.Value);
                    }
                }
                connection.Open();
                command.Connection = connection;
                SqlDataReader reader = command.ExecuteReader();
                /*SqlDataReader is used to read the data from sql server
                  SqlDataReader is readonly
                  SqlDataReader is forward only
                 */
                DataTable dt = new DataTable();
                dt.Load(reader);
                return dt;
            }
            catch (Exception ex) { }
            finally
            {
                connection.Close();
                connection.Dispose();
                command.Dispose();
            }
            return null;
        }
    }
}
