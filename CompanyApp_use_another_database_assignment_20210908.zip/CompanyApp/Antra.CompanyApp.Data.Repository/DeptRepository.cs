﻿using System;
using System.Collections.Generic;
using System.Data;
using Antra.CompanyApp.Data.Model;

namespace Antra.CompanyApp.Data.Repository
{
    public class RegionRepository : IRepository<Region>
    {
        DBHelper db;
        public RegionRepository()
        {
            db = new DBHelper();
        }
        public int Delete(int id)
        {
            string cmd = "Delete from Region where Id=@regionid";
            Dictionary<string, object> p = new Dictionary<string, object>();
            p.Add("@regionid", id);
            return db.Execute(cmd, p);
        }

        public IEnumerable<Region> GetAll()
        {
            // string cmd = "Select RegionId, RegionDescription from Region";
            string cmd = "spGetAllRegion";
            DataTable dt = db.Query(cmd, null,CommandType.StoredProcedure);
            List<Region> deptCollection = new List<Region>();
            if (dt != null)
            {
                foreach (DataRow item in dt.Rows)
                {
                    Region d = new Region();
                    Region.RegionId = Convert.ToInt32(item["RegionId"]);
                    Region.RegionDescription = Convert.ToString(item["RegionDescription"]);
                 

                    regionCollection.Add(d);

                }
                return regionCollection;
            }
            return null;
        }

        public Dept GetById(int id)
        {
            throw new NotImplementedException();
        }

        public int Insert(Region item)
        {
            string cmd = "Insert into Region values (@regionid,@regiondescription)";
            Dictionary<string, object> p = new Dictionary<string, object>();
            p.Add("@regionid", item.RegionId);
            p.Add("@regiondescription", item.RegionDescription);
            return db.Execute(cmd, p);
        }

        public int Update(Region item)
        {
            string cmd = "Update Region set RegionId=@regionid, RegionDescription=@regiondescription where RegionId=@regionid";
            Dictionary<string, object> p = new Dictionary<string, object>();
            p.Add("@regionid", item.RegionId);
            p.Add("@regiondescription", item.RegionDescription);
            return db.Execute(cmd, p);
        }
    }
}
